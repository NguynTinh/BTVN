insert into NHANVIEN(MANV, HOTEN, SODT, NGVL) 
values('NV01', 'Nguyen Nhu Nhut', '0927345678', 13/4/2006)

GO
insert into NHANVIEN(MANV, HOTEN, SODT, NGVL) 
values('NV02', 'Le Thi Phi Yen', '0987567390', 21/4/2006)

GO
insert into NHANVIEN(MANV, HOTEN, SODT, NGVL) 
values('NV03', 'Nguyen Van B', '0997047382', 27/4/2006)

GO
insert into NHANVIEN(MANV, HOTEN, SODT, NGVL) 
values('NV04', 'Ngo Thanh Tuan', '0913758498', 24/6/2006)

GO
insert into NHANVIEN(MANV, HOTEN, SODT, NGVL) 
values('NV05', 'Nguyen Thi Truc Thanh', '0918590387', 20/7/2006)