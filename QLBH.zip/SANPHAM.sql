insert into SANPHAM ( MASP, TENSP, DVT , NUOCSX , GIA) 
values('BC01', 'But chi' ,'cay' ,'Singapore' ,3000)

GO
insert into SANPHAM(MASP,TENSP,DVT,NUOCSX,GIA) 
values('BC02' ,'But chi' ,'cay' ,'Singapore',5000)

GO
insert into SANPHAM(MASP,TENSP,DVT,NUOCSX,GIA) 
values('BC03', 'But chi' ,'cay', 'Viet Nam' ,3500)

GO
insert into SANPHAM(MASP,TENSP,DVT,NUOCSX,GIA) 
values('BC04' ,'But chi', 'HOP', 'Viet Nam', 30000)

GO
insert into SANPHAM(MASP,TENSP,DVT,NUOCSX,GIA) 
values('BB01', 'But bi' ,'cay', 'Viet Nam',5000)
GO
insert into SANPHAM(MASP,TENSP,DVT,NUOCSX,GIA) 
values('BB02' ,'But bi' ,'cay', 'Trung Quoc', 7000)

GO
insert into SANPHAM(MASP,TENSP,DVT,NUOCSX,GIA) 
values('BB03', 'But bi', 'hop' ,'Thai Lan', 100000)

GO
insert into SANPHAM(MASP,TENSP,DVT,NUOCSX,GIA) 
values('TV01' ,'Tap 100 giay mong', 'quyen' ,'Trung Quoc', 2500)

GO
insert into SANPHAM(MASP,TENSP,DVT,NUOCSX,GIA) 
values('TV02', 'Tap 200 giay mong', 'quyen', 'Trung Quoc', 4500)
GO
insert into SANPHAM(MASP,TENSP,DVT,NUOCSX,GIA) 
values('TV03' ,'Tap 100 giay tot' ,'quyen', 'Viet Nam', 3000)

GO
insert into SANPHAM(MASP,TENSP,DVT,NUOCSX,GIA) 
values('TV04' ,'Tap 200 giay tot' ,'quyen', 'Viet Nam', 5500)

GO
insert into SANPHAM(MASP,TENSP,DVT,NUOCSX,GIA) 
values('TV05' ,'Tap 100 trang', 'chuc' ,'Viet Nam', 23000)

GO
insert into SANPHAM(MASP,TENSP,DVT,NUOCSX,GIA) 
values('TV06' ,'Tap 200 trang', 'chuc', 'Viet Nam', 53000)
GO
insert into SANPHAM(MASP,TENSP,DVT,NUOCSX,GIA) 
values('TV07', 'Tap 100 trang', 'chuc', 'Trung Quoc', 34000)

GO
insert into SANPHAM(MASP,TENSP,DVT,NUOCSX,GIA) 
values('ST01' ,'So tay 500 trang', 'quyen', 'Trung Quoc' ,40000)

GO
insert into SANPHAM(MASP,TENSP,DVT,NUOCSX,GIA) 
values('ST02', 'So tay loai 1', 'quyen', 'Viet Nam', 55000)

GO
insert into SANPHAM(MASP,TENSP,DVT,NUOCSX,GIA) 
values('ST03', 'So tay loai 2', 'quyen', 'Viet Nam', 51000)
GO
insert into SANPHAM(MASP,TENSP,DVT,NUOCSX,GIA) 
values('ST04', 'So tay', 'quyen', 'Thai Lan', 55000)

GO
insert into SANPHAM(MASP,TENSP,DVT,NUOCSX,GIA) 
values('ST05' ,'So tay mong', 'quyen', 'Thai Lan' ,20000)

GO
insert into SANPHAM(MASP,TENSP,DVT,NUOCSX,GIA) 
values('ST06', 'Phan viet bang', 'hop' ,'Viet Nam', 5000)

GO 1
insert into SANPHAM(MASP,TENSP,DVT,NUOCSX,GIA) 
values('ST07' ,'Phan khong bui' ,'hop' ,'Viet Nam', 7000)
GO
insert into SANPHAM(MASP,TENSP,DVT,NUOCSX,GIA) 
values('ST08' ,'Bong bang', 'cai' ,'Viet Nam' ,1000)

GO
insert into SANPHAM(MASP,TENSP,DVT,NUOCSX,GIA) 
values('ST09' ,'But long', 'cay', 'Viet Nam', 5000)

GO
insert into SANPHAM(MASP,TENSP,DVT,NUOCSX,GIA) 
values('ST10' ,'But long', 'cay', 'Trung Quoc', 7000)
