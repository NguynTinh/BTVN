create table KHACHHANG
(
MAKH char(4) Primary Key,
HOTEN varchar(40),
DCHI varchar(50),
SODT varchar(20),
NGSINH smalldatetime,
NGDK smalldatetime,
DOANHSO money
)

GO

create table NHANVIEN
(
MANV char(4) Primary Key,
HOTEN varchar(40),
SODT varchar(20),
NGVL smalldatetime
)

GO

create table SANPHAM
(
MASP char(4) Primary Key,
TENSP varchar(40),
DVT varchar(20),
NUOCSX varchar(40),
GIA money
)

GO

create table HOADON
(
SOHD int Primary Key,
NGHD smalldatetime,
MAKH char(4) Foreign Key References KHACHHANG(MAKH),
MANV char(4) Foreign Key References NHANVIEN(MANV),
TRIGIA money
)

GO

create table CTHD
(
SOHD int Foreign Key References HOADON(SOHD),
MASP char(4) Foreign Key References SANPHAM(MASP),
SL int
)