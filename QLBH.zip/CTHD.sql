
insert into CTHD(SOHD, MASP,SL) 
values(1001, 'TV02', 10)
GO
insert into CTHD(SOHD, MASP,SL) 
values(1001 ,'ST01', 5)
GO
insert into CTHD(SOHD, MASP,SL) 
values(1001 ,'BC01', 5)
GO
insert into CTHD(SOHD, MASP,SL) 
values(1001 ,'BC02', 10)
GO
insert into CTHD(SOHD, MASP,SL) 
values(1001 ,'ST08', 10)
GO
insert into CTHD(SOHD, MASP,SL) 
values(1002 ,'BC04', 20)
GO
insert into CTHD(SOHD, MASP,SL) 
values(1002 ,'BB01', 20)
GO
insert into CTHD(SOHD, MASP,SL) 
values(1002 ,'BB02', 20)
GO
insert into CTHD(SOHD, MASP,SL) 
values(1003 ,'BB03', 10)
GO
insert into CTHD(SOHD, MASP,SL) 
values(1004 ,'TV01', 20)
GO
insert into CTHD(SOHD, MASP,SL) 
values(1004 ,'TV02', 10)
GO
insert into CTHD(SOHD, MASP,SL) 
values(1004 ,'TV03', 10)
GO
insert into CTHD(SOHD, MASP,SL) 
values(1004 ,'TV04', 10)
GO
insert into CTHD(SOHD, MASP,SL) 
values(1005 ,'TV05', 50)
GO
insert into CTHD(SOHD, MASP,SL) 
values(1005 ,'TV06', 50)
GO
insert into CTHD(SOHD, MASP,SL) 
values(1006 ,'TV07', 20)
GO
insert into CTHD(SOHD, MASP,SL) 
values(1006 ,'ST01', 30)
GO
insert into CTHD(SOHD, MASP,SL) 
values(1006 ,'ST02', 10)
GO
insert into CTHD(SOHD, MASP,SL) 
values(1007 ,'ST03', 10)
GO
insert into CTHD(SOHD, MASP,SL) 
values(1008 ,'ST04', 8)
GO
insert into CTHD(SOHD, MASP,SL) 
values(1009 ,'ST05', 10)
GO
insert into CTHD(SOHD, MASP,SL) 
values(1010 ,'TV07', 50)
GO
insert into CTHD(SOHD, MASP,SL) 
values(1010 ,'ST07', 50)
GO
insert into CTHD(SOHD, MASP,SL) 
values(1010 ,'ST08', 100)
GO
insert into CTHD(SOHD, MASP,SL) 
values(1010 ,'ST04', 50)
GO
insert into CTHD(SOHD, MASP,SL) 
values(1010 ,'TV03', 100)
GO
insert into CTHD(SOHD, MASP,SL) 
values(1011 ,'ST06', 50)
GO
insert into CTHD(SOHD, MASP,SL) 
values(1012 ,'ST07', 3)
GO
insert into CTHD(SOHD, MASP,SL) 
values(1013 ,'ST08', 5)
GO
insert into CTHD(SOHD, MASP,SL) 
values(1014 ,'BC02', 80)
GO
insert into CTHD(SOHD, MASP,SL) 
values(1014 ,'BB02', 100)
GO
insert into CTHD(SOHD, MASP,SL) 
values(1014 ,'BC04', 60)
GO
insert into CTHD(SOHD, MASP,SL) 
values(1014 ,'BB01', 50)
GO
insert into CTHD(SOHD, MASP,SL) 
values(1015 ,'BB02', 30)
GO
insert into CTHD(SOHD, MASP,SL) 
values(1015 ,'BB03', 7)
GO
insert into CTHD(SOHD, MASP,SL) 
values(1016 ,'TV01', 5)
GO
insert into CTHD(SOHD, MASP,SL) 
values(1017 ,'TV02', 1)
GO
insert into CTHD(SOHD, MASP,SL) 
values(1017 ,'TV03', 1)
GO
insert into CTHD(SOHD, MASP,SL) 
values(1017 ,'TV04', 5)
GO
insert into CTHD(SOHD, MASP,SL) 
values(1018 ,'ST04', 6)
GO
insert into CTHD(SOHD, MASP,SL) 
values(1019 ,'ST05', 1)
GO
insert into CTHD(SOHD, MASP,SL) 
values(1019 ,'ST06', 2)
GO
insert into CTHD(SOHD, MASP,SL) 
values(1020 ,'ST07', 10)
GO
insert into CTHD(SOHD, MASP,SL) 
values(1021 ,'ST08', 5)
GO
insert into CTHD(SOHD, MASP,SL) 
values(1021 ,'TV01', 7)
GO
insert into CTHD(SOHD, MASP,SL) 
values(1021 ,'TV02', 10)
GO
insert into CTHD(SOHD, MASP,SL) 
values(1022 ,'ST07', 1)
GO
insert into CTHD(SOHD, MASP,SL) 
values(1023 ,'ST04', 6)
