insert into LOP (MALOP, TENLOP, TRGLOP, SISO, MAGVCN) 
values ('K11', 'Lop 1 Khoa 1', 'K1108', 11, 'GV07')
GO
insert into LOP (MALOP, TENLOP, TRGLOP, SISO, MAGVCN)
values ('K12', 'Lop 2 khoa 1', 'K1205', 12,'GV09')
GO
insert into LOP (MALOP, TENLOP, TRGLOP, SISO, MAGVCN)
values ('K13', 'Lop 3 khoa 1','K1305', 12,'GV14')