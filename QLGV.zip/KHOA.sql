insert into KHOA(MAKHOA, TENKHOA,NGTLAP, TRGKHOA) 
values ('KHMT', 'Khoa hoc may tinh', 7/6/2005, 'GV01')
GO
insert into  KHOA(MAKHOA, TENKHOA,NGTLAP, TRGKHOA) 
values ('HTTT', 'He thong thong tin', 7/6/2005,'GV02')
GO
insert into KHOA(MAKHOA, TENKHOA,NGTLAP, TRGKHOA) 
values ('CNPM', 'Cong nghe phan mem', 7/6/2005, 'GV04')
GO
insert into KHOA(MAKHOA, TENKHOA,NGTLAP, TRGKHOA) 
values ('MTT', 'Mang va truyen thong', 20/10/2005, 'GV03')
GO
insert into KHOA(MAKHOA, TENKHOA,NGTLAP, TRGKHOA) 
values ('KTMT','Ky thuat may tinh', 20/12/2005, 'Null')