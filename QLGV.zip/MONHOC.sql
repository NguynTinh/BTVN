insert into MONHOC(MAMH, TENMH, TCLT, TCTH, MAKHOA)
values ('THDC', 'Tin hoc dai cuong', 4, 1, 'KHMT')
GO
insert into MONHOC(MAMH, TENMH, TCLT, TCTH, MAKHOA)
values ('CTRR', 'Cau truc roi rac', 5, 0, 'KHMT')
GO
insert into MONHOC(MAMH, TENMH, TCLT, TCTH, MAKHOA)
values ('CSDL', 'Co so du lieu', 3, 1, 'HTTT')
GO
insert into MONHOC(MAMH, TENMH, TCLT, TCTH, MAKHOA)
values ('CTDLGT', 'Cau truc du lieu va giai thuat', 3, 1, 'KHMT')
GO
insert into MONHOC(MAMH, TENMH, TCLT, TCTH, MAKHOA)
values ('PTTKTT', 'Phan tich thiet ke thuat toan', 3, 0, 'KHMT')
GO
insert into MONHOC(MAMH, TENMH, TCLT, TCTH, MAKHOA)
values ('DHMT', 'Do hoa may tinh', 3, 1, 'KHMT')
GO
insert into MONHOC(MAMH, TENMH, TCLT, TCTH, MAKHOA)
values ('KTMT', 'Kien truc may tinh', 3, 0,'KTMT')
GO
insert into MONHOC(MAMH, TENMH, TCLT, TCTH, MAKHOA)
values ('TKCSDL', 'Thiet ke co so du lieu', 3, 1, 'HTTT')
GO
insert into MONHOC(MAMH, TENMH, TCLT, TCTH, MAKHOA)
values ('PTTKHTTT', 'Phan tich thiet ke he thong thong tin', 4, 1, 'HTTT')
GO
insert into MONHOC(MAMH, TENMH, TCLT, TCTH, MAKHOA)
values ('HDH', 'He dieu hanh', 4, 0, 'KTMT')
GO
insert into MONHOC(MAMH, TENMH, TCLT, TCTH, MAKHOA)
values ('NMCNPM', 'Nhap mon cong nghe phan mem', 3, 0, 'CNPM')
GO
insert into MONHOC(MAMH, TENMH, TCLT, TCTH, MAKHOA)
values ('LTCFW', 'Lap trinh C for win', 3, 1, 'CNPM')
GO
insert into MONHOC(MAMH, TENMH, TCLT, TCTH, MAKHOA)
values ('LTHDT', 'Lap trinh huong doi tuong', 3, 1,'CNPM')