insert into DIEUKIEN(MAMH, MAMH_TRUOC)
values ('CSDL', 'CTRR')
GO
insert into DIEUKIEN(MAMH, MAMH_TRUOC)
values ('CSDL', 'CTDLGT')
GO
insert into DIEUKIEN(MAMH, MAMH_TRUOC)
values ('CTDLGT', 'THDC')
GO
insert into DIEUKIEN(MAMH, MAMH_TRUOC)
values ('PTTKTT', 'THDC')
GO
insert into DIEUKIEN(MAMH, MAMH_TRUOC)
values ('PTTKTT', 'CTDLGT')
GO
insert into DIEUKIEN(MAMH, MAMH_TRUOC)
values ('DHMT', 'THDC')
GO
insert into DIEUKIEN(MAMH, MAMH_TRUOC)
values ('LTHDT', 'THDC')
GO
insert into DIEUKIEN(MAMH, MAMH_TRUOC)
values ('PTTKHTTT', 'CSDL')