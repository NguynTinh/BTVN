
create table LOP
(
MALOP char(3) Primary Key,
TENLOP varchar(40),
TRGLOP char(5),
SISO tinyint,
MAGVCN char(4)
)

GO

create table HOCVIEN
(
MAHV char(5) Primary Key,
HO varchar(40),
TEN varchar(10),
NGSINH smalldatetime,
GIOITINH varchar(3),
NOISINH varchar(40),
MALOP char(3) Foreign Key References LOP(MALOP)
)

GO

create table KHOA
(
MAKHOA varchar(4) Primary Key,
TENKHOA varchar(40),
NGTLAP smalldatetime,
TRGKHOA char(4)
)

GO

create table MONHOC
(
MAMH varchar(10) Primary Key,
TENMH varchar(40),
TCLT tinyint,
TCTH tinyint,
MAKHOA varchar(4) Foreign Key References KHOA(MAKHOA)
)

GO

create table DIEUKIEN
(
MAMH varchar(10) Foreign Key References MONHOC(MAMH),
MAMH_TRUOC varchar(10)
)

GO

create table GIAOVIEN
(
MAGV char(4) Primary Key,
HOTEN varchar(40),
HOCVI varchar(10),
HOCHAM varchar(10),
GIOITINH varchar(3),
HESO numeric(4,2),
MUCLUONG money,
MAKHOA varchar(4) Foreign Key References KHOA(MAKHOA)
)

GO

create table GIANGDAY
(
MALOP char(3) Foreign Key References LOP(MALOP),
MAMH varchar(10) Foreign Key References MONHOC(MAMH),
MAGV char(4) Foreign Key References GIAOVIEN(MAGV),
HOCKY tinyint,
NAM smallint,
TUNGAY smalldatetime,
DENNGAY smalldatetime
)

GO

create table KETQUATHI
(
MAHV char(5) Foreign Key References HOCVIEN(MAHV),
MAMH varchar(10) Foreign Key References MONHOC(MAMH),
LANTHI tinyint,
NGTHI smalldatetime,
DIEM numeric(4,2),
KQUA varchar(10)
)